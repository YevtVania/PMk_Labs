# Component constraints for D:\project\CSN_UzhNU\CSN_UzhNU\zavd1.cydsn\TopDesign\TopDesign.cysch
# Project: D:\project\CSN_UzhNU\CSN_UzhNU\zavd1.cydsn\zavd1.cyprj
# Date: Sat, 21 Feb 2026 16:35:57 GMT
