-- ======================================================================
-- zavd1.ctl generated from zavd1
-- 02/21/2026 at 18:35
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
