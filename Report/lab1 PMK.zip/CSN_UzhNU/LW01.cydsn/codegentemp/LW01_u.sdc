# Component constraints for D:\project\CSN_UzhNU\CSN_UzhNU\LW01.cydsn\TopDesign\TopDesign.cysch
# Project: D:\project\CSN_UzhNU\CSN_UzhNU\LW01.cydsn\LW01.cyprj
# Date: Mon, 16 Feb 2026 09:41:15 GMT
