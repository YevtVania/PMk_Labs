-- ======================================================================
-- LW01.ctl generated from LW01
-- 02/16/2026 at 11:41
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
